(function() {
    Type.registerNamespace('ITSP');
    ITSP = ITSP ? ITSP : {};
    ITSP.SP=ITSP.SP ? ITSP.SP : {};
    
    ITSP.SP.AttachmentField = function(){
    var self=this;
    this.ready=false; 
    this.currentListItemAttachments;
    this.asyncMessage=null;
    this.attachmentCallout=null;
    this.currentItemId = -1;
    this.listName = "";
    this.spanElementId = "";
    this.webUrl="";
    this.context = null;
    this.currentSite = null;
    this.currentWeb = null;
    this.currentList = null;
    this.currentListItem = null;
    this.currentListItemAttachments = null;
    this.delegateQueue = [];
    
    this.showAttachmentInformation=function(webUrl, currentListTitle, currentItemId, spanElementId) {
        self.currentItemId = currentItemId;
        self.listName = currentListTitle;
        self.spanElementId = spanElementId;
        self.webUrl=webUrl;

        self.context = SP.ClientContext.get_current();
        self.currentSite = self.context.get_site();
        self.currentWeb = self.context.get_web();
        self.currentList = self.currentWeb.get_lists().getByTitle(self.listName);
        self.currentListItem = self.currentList.getItemById(currentItemId);
        self.currentListItemAttachments = self.currentListItem.get_attachmentFiles();
        self.delegateQueue = [];
        self.asyncMessage = null;
        self.ready = false;
        self.attachmentCallout = null;

        self.context.load(self.currentSite);
        self.context.load(self.currentWeb, 'Title', 'Description');
        self.context.load(self.currentList);
        self.context.load(self.currentListItem, 'Title', 'DisplayName');
        self.context.load(self.currentListItemAttachments);

        self.context.executeQueryAsync(
            Function.createDelegate(this, self.webLoadSuccess),
            Function.createDelegate(this, self.asyncCallFailed)
        );  
    };
    
    this.getAttachmentFieldOverrideTemplate = function(hostObject) {
        var attachmentFieldContext = {};
        // You can provide templates for:
        // View, DisplayForm, EditForm and NewForm
        attachmentFieldContext.Templates = {};
        attachmentFieldContext.Templates.Fields = {
            "Attachments": {
                "View": hostObject.listViewTemplate
            }
        };

        return attachmentFieldContext;
    };
    
    this.listViewTemplate = function(ctx){
        var schemaName = ctx.CurrentFieldSchema.Name;
            var fieldRender = new AttachmentFieldRenderer(schemaName);
            var fieldRenderedHtml = "";
            var attachmentRenderedHtml = fieldRender.RenderField(ctx, ctx.CurrentFieldSchema, ctx.CurrentItem, ctx.ListSchema);

            if (ctx.CurrentItem.Attachments != undefined) {
                var hasAttachments = ctx.CurrentItem.Attachments;
                if (hasAttachments) {
                    //output attachment clip
                    var spanElementId = "attachmentField_ListItem_Span_" + ctx.wpq + "_" + ctx.CurrentItem.ID;
                    fieldRenderedHtml = "<div title='Click to view attachments' id='" + spanElementId + "' style='cursor:pointer;' class='link-set' onclick='javascript:ITSP.AttachmentFieldRenderOverrideControl.showAttachmentInformation(\"" + ctx.HttpRoot + "\", \"" + ctx.ListTitle + "\", " + ctx.CurrentItem.ID + ", \"" + spanElementId + "\");'>" + attachmentRenderedHtml + "</div>";
                }

            }
  
        return fieldRenderedHtml;   
    };
    
    this.webLoadSuccess=function(sender, args) {
            self.ready = true;
            self.asyncMessage = "success";
            
            console.log("loaded item attachments");

            var attachmentCount = self.currentListItemAttachments.get_count();
            var attachmentContentHtml = "";
            if (attachmentCount > 0) { //execute queued functions
                for (i = 0; i < attachmentCount; i++) {
                    var attachmentFile = self.currentListItemAttachments.getItemAtIndex(i);
                    var attachmentFilePath = attachmentFile.get_serverRelativeUrl();

                    attachmentContentHtml = attachmentContentHtml + "<li><a href='" + attachmentFilePath + "' target='_new'>" + attachmentFile.get_fileName() + "</a></li>";
                }
            }

            var link = document.getElementById(self.spanElementId);
            var calloutContent = "<p>There are " + attachmentCount + " attachments.</p> <p><ul>" + attachmentContentHtml + "</ul></p>";
            var calloutId=self.currentItemId + "attachmentCallout";
            var calloutTitle = "Attachments: " + self.currentListItem.get_displayName();


            SP.SOD.executeFunc("callout.js", "Callout", function() {
                self.openCallout(calloutId, link, calloutContent, calloutTitle);
            });
        };
        this.asyncCallFailed=function(sender, args) {
                self.ready = true;
                self.asyncMessage = args.get_message() + " " + args.get_stackTrace();
                console.log("asynccallfailed " + self.asyncMessage);
        };
        
        
        this.openCallout=function(id, launchPoint, content, title) {
            var calloutOptions = new CalloutOptions();
            calloutOptions.ID = id;
            calloutOptions.launchPoint = launchPoint;
            calloutOptions.beakOrientation = "leftRight";
            calloutOptions.content = content;
            calloutOptions.title = title;
            self.attachmentCallout = CalloutManager.createNewIfNecessary(calloutOptions);
            self.attachmentCallout.open();
        };
        
        
    
    return {
        isReady: function() {
            return self.ready;
        },
        getAttachments: function() {
            return self.currentListItemAttachments;
        },
        listViewTemplate: function(ctx){
            return self.listViewTemplate(ctx);
        },
        registerOverrideTemplate: function(host){
            var template=self.getAttachmentFieldOverrideTemplate(host);
            SPClientTemplates.TemplateManager.RegisterTemplateOverrides(template);
        },
        showAttachmentInformation: function(webUrl, currentListTitle, currentItemId, spanElementId) {
            self.showAttachmentInformation(webUrl, currentListTitle, currentItemId, spanElementId);   
        }    
    }
};

function RegisterAttachmentControlInMDS() {
    console.log("Detected MDS and registering with MDS")
    // RegisterFilenameFiledContext-override for MDS enabled site
    InitialiseAttachmentControl();
    var thisUrl = _spPageContextInfo.siteServerRelativeUrl + "/SiteAssets/Scripts/ITSP.SP.AttachmentField.js";
    RegisterModuleInit(thisUrl, InitialiseAttachmentControl);
    //RegisterFilenameFiledContext-override for MDS disabled site (because we need to call the entry point function in this case whereas it is not needed for anonymous functions)
    
    return true;   
}

function InitialiseAttachmentControl()
{
    console.log("InitialiseAttachmentControl")
    ITSP.AttachmentFieldRenderOverrideControl = new ITSP.SP.AttachmentField();
    ITSP.AttachmentFieldRenderOverrideControl.registerOverrideTemplate(ITSP.AttachmentFieldRenderOverrideControl);
}

if (typeof _spPageContextInfo != "undefined" && _spPageContextInfo != null) {
    RegisterAttachmentControlInMDS();
}
else {
    InitialiseAttachmentControl();;
}
})();